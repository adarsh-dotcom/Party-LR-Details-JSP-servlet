package com.master.page.servlet.jsp;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;

import java.io.IOException;

@WebServlet("/anotherServlet")
public class PartyDetServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       

    public PartyDetServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		 String partyCode = request.getParameter("Party_code");
	        
	        // Store the Party_code value in the database (assuming you have database logic here)
	        // Example:
	        // YourDatabaseClass.storePartyCode(partyCode);
	        
	        // Store the Party_code value in a session attribute
	        HttpSession session = request.getSession();
	        session.setAttribute("partyCode", partyCode);
	        
	        // Redirect to anotherServlet.jsp
	        response.sendRedirect("anotherServlet.jsp");
	}

}
